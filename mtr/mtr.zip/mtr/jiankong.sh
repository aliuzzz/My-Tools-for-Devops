#!/bin/bash/
sh /root/mtr.sh 华北-山东 青岛-云基地电信 易吉特-联通 119.167.153.176 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-云基地电信 易吉特-电信 219.146.94.48 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 勤和-联通 27.221.58.116 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 勤和-电信 150.138.123.72 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 兆言-联通 123.234.3.114 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 兆言-电信 150.138.148.50 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 兆言-移动 120.221.27.114 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 六间房-联通 27.221.5.3 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 六间房-电信 150.138.148.226 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 六间房-移动 120.221.85.194 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-株洲路三线 瞬守-电信 150.138.123.130 1 nancy@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-高新区电信 京东-电信 140.249.58.3 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-高新区电信 京东-电信 150.138.120.254 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-高新区电信 兆言-电信 150.138.182.2 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-高新区电信 六间房-电信 150.138.141.135 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-高新区电信 游家-电信 150.138.141.199 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 青岛-青云移动 4399-移动 120.221.232.181 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 济宁-联通机房 零与壹-联通 60.211.182.201 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 临沂-联通机房 金山1-联通 60.213.22.19 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 临沂-联通机房 金山2-联通 60.213.22.140 1 liujun@wxdata.cn
sh /root/mtr.sh 华北-山东 临沂-联通机房 头条-联通 60.213.21.21 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 华多-联通 61.133.52.245 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 头条-联通 61.133.50.21 1 xuemiaojun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 4399-联通 60.212.16.196 1 liujun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 又拍-联通 61.179.104.38 1 liujun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 游家-联通 61.156.16.44 1 liujun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 网易-联通 61.179.104.67 1 liujun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 六间房-联通 123.130.117.37 1 nancy@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 金山1-联通 60.212.94.14 1 nancy@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 金山2-联通 61.179.104.147 1 nancy@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 华为-联通 61.179.107.2 1 liujun@wxdata.cn
sh /root/mtr.sh 华北-山东 烟台-联通机房 兆言-联通 61.156.16.65 1 nancy@wxdata.cn
sh /root/mtr.sh 华北-山东 枣庄-联通机房 阿里-联通 124.132.134.177 1 nancy@wxdata.cn
sh /root/mtr.sh 华北-山东 淄博-联通机房 腾讯-联通 61.156.152.100 1 liujun@wxdata.cn
sh /root/mtr.sh 华北-山东 枣庄-联通机房 阿里-联通 124.132.135.244 1 nancy@wxdata.cn
sh /root/mtr.sh 华中-河南 许昌-联通机房 游家-联通 125.46.42.213 1 xuduo@wxdata.cn
sh /root/mtr.sh 华中-河南 郑州-移动机房 游家-移动 111.7.98.67 1 xuduo@wxdata.cn
sh /root/mtr.sh 华北-河北 石家庄-三线 兆言-联通 110.249.211.2 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华北-河北 石家庄-三线 兆言-移动 111.62.214.50  1 jiangqi@wxdata.cn
sh /root/mtr.sh 华北-河北 石家庄-三线 兆言-电信 124.236.115.34 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华北-河北 石家庄-移动机房 兆言-移动 111.62.100.129 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华北-河北 石家庄-移动机房 游家-移动 111.62.82.133 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华东-浙江 温州-三线机房 六间房-电信 122.228.90.89 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华东-浙江 温州-三线机房 六间房-联通 123.159.205.154 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华东-浙江 温州-三线机房 六间房-移动 117.149.198.56 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华东-安徽 淮南-移动机房 迅雷-移动 112.29.212.2 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华东-安徽 淮南-移动机房 头条-移动 112.29.205.32 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华东-安徽 淮南-移动机房 兆言-移动 112.29.205.129 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华东-安徽 合肥-移动机房 六间房-移动 112.28.221.5 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华中-河南 洛阳-三线 六间房-电信 222.88.93.13 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华中-河南 洛阳-三线 六间房-联通 61.54.25.13 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华中-河南 洛阳-三线 兆言-电信 222.88.93.130 1 jiangqi@wxdata.cn
sh /root/mtr.sh 华中-河南 洛阳-三线 兆言-联通 61.54.29.98 0 
sh /root/mtr.sh 华中-河南 洛阳-三线 兆言-移动 111.6.96.130 0 
sh /root/mtr.sh 东北-吉林 长春-联通机房 六间房-联通 139.215.243.131 0 
sh /root/mtr.sh 东北-黑龙江 哈尔滨-电信机房 游家-电信 42.101.73.196 0 
sh /root/mtr.sh 东北-辽宁 沈阳-电信机房 360-电信 59.44.45.135 0 
sh /root/mtr.sh 东北-辽宁 大连-电信机房 阿里-电信 42.202.156.2 0 
sh /root/mtr.sh 东北-辽宁 大连-电信机房 游家-电信 182.201.243.18 0 
sh /root/mtr.sh 东北-辽宁 大连-电信机房 兆言-电信 182.201.243.2 0 
sh /root/mtr.sh 东北-辽宁 大连-移动机房 兆言-移动 120.201.35.130 0 
sh /root/mtr.sh 东北-辽宁 大连-移动机房 金山-移动 120.201.242.19 0 
sh /root/mtr.sh 东北-辽宁 大连-联通机房 华为-联通 218.60.100.2 0 
sh /root/mtr.sh 东北-辽宁 大连-联通机房 兆言-联通 42.7.51.2 0 
sh /root/mtr.sh 东北-辽宁 大连-联通机房 阿里-联通 42.7.50.239 0 
sh /root/mtr.sh 华东-福建 福州-电信机房 六间房-电信 59.56.18.20 0 
sh /root/mtr.sh 华北-甘肃 兰州-电信机房 游家-电信 118.182.231.214 0 
sh /root/mtr.sh 华北-甘肃 兰州-移动机房 游家-移动 117.157.237.98 0 
sh /root/mtr.sh 华北-内蒙古 呼和浩特-电信机房 兆言-电信 1.180.236.2 0 
sh /root/mtr.sh 华北-内蒙古 呼和浩特-电信机房 游家-电信 1.180.236.68 0 
sh /root/mtr.sh 西南-四川 成都-电信机房 六间房-电信 182.140.239.68 0 
sh /root/mtr.sh 华中-湖南 株洲-电信机房 游家-电信 220.170.187.67 0 
sh /root/mtr.sh 西南-四川 咸阳-联通机房 兆言-联通 113.200.41.66 0 
sh /root/mtr.sh 西北-陕西 西安-电信机房 兆言-电信 36.41.170.2 0 
sh /root/mtr.sh 华中-湖北 襄阳-三线机房 兆言-联通 119.36.141.34 0 
sh /root/mtr.sh 华中-湖北 襄阳-三线机房 兆言-电信 111.177.9.130 0 
sh /root/mtr.sh 华中-湖北 襄阳-三线机房 兆言-移动 111.48.83.178 0 

